﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using BLL;
using MQTTnet;
using MQTTnet.Protocol;
using MQTTnet.Server;
using Newtonsoft.Json;
using MathNet.Numerics.Distributions;
using DAL;

namespace UI
{
    public partial class MQTTFORM : Form
    {
        public MQTTFORM()
        {
            InitializeComponent();
            var options = new MqttServerOptionsBuilder()
                    .WithDefaultEndpoint()
                    .WithDefaultEndpointBoundIPAddress(IPAddress.Parse("127.0.0.1"))
                    .WithDefaultEndpointPort(1883)
                    .WithDefaultCommunicationTimeout(TimeSpan.FromMilliseconds(5000))
                    .Build();
            mqttServer = new MqttFactory().CreateMqttServer(options);
        }
        //对象
        private MqttServer mqttServer;

        //主题,用来存储名为学号，内容为考试内容的主题

        private Dictionary<string, List<string>> clientSubscriptions = new Dictionary<string, List<string>>();

        // 客户端连接事件
        private Task OnClientConnected(ClientConnectedEventArgs e)
        {
            BeginInvoke(new Action(() =>
            {
                lt_Users.Items.Add($">>> 客户端【{e.ClientId}】账户【{e.UserName}】加入连接");
            }));
            return Task.CompletedTask;
        }

        // 客户端断开事件
        private Task OnClientDisconnected(ClientDisconnectedEventArgs e)
        {
            BeginInvoke(new Action(() =>
            {
                // 遍历列表项，查找包含当前客户端ID的字符串
                var targetItem = lt_Users.Items.Cast<string>()
                    .FirstOrDefault(item => item.Contains($"客户端【{e.ClientId}】"));

                if (targetItem != null)
                {
                    lt_Users.Items.Remove(targetItem); // 移除匹配的完整字符串
                }
            }));
            return Task.CompletedTask;
        }

        //订阅处理
        private Task OnClientSubscribed(ClientSubscribedTopicEventArgs e)
        {
            lock (clientSubscriptions)
            {
                if (!clientSubscriptions.ContainsKey(e.ClientId))
                {
                    clientSubscriptions[e.ClientId] = new List<string>();
                }
                clientSubscriptions[e.ClientId].Add(e.TopicFilter.Topic);

                // 示例：当客户端订阅 student/ 主题时，立即查询并发布
                if (e.TopicFilter.Topic.StartsWith("student/"))
                {
                    Task.Run(async () => await PublishStudentData(e.TopicFilter.Topic));
                }
            }
            return Task.CompletedTask;
        }

        //发布处理
        private async Task PublishStudentData(string topic)
        {
            try
            {
                // 1. 解析主题，获取学号（如 topic = "student/2025001"，则学号是 2025001）
                string studentId = topic.Split('/').Last();

                // 2. 从数据库查询学生数据（示例，需根据实际业务调整）
                List<StudentExamData> student = await USERBLL.GetStudentByIdAsync(studentId);
                if (student == null)
                {
                    return;
                }

                // 3. 序列化为 JSON
                string payload = JsonConvert.SerializeObject(student);
                byte[] payloadBytes = Encoding.UTF8.GetBytes(payload);

                // 4. 发布消息到主题
                var appMsg = new MqttApplicationMessageBuilder()
                    .WithTopic(topic)
                    .WithPayload(payloadBytes)
                    .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
                    .Build();
                var message = new InjectedMqttApplicationMessage(appMsg);
                await mqttServer.InjectApplicationMessage(message);

                // 调试输出
                BeginInvoke(new Action(() =>
                {
                    lt_Theme.Items.Add($"已发布数据到主题 {topic}");
                }));
            }
            catch (Exception ex)
            {
                BeginInvoke(new Action(() =>
                {
                    lt_Theme.Items.Add($"发布失败: {ex.Message}");
                }));
            }
        }

        //连接认证
        private async Task HandleValidatingConnectionAsync(ValidatingConnectionEventArgs context)
        {
            try
            {
                string clientUsername = context.UserName;
                string clientPassword = context.Password;

                // 检查用户名密码是否为空
                if (string.IsNullOrWhiteSpace(clientUsername) || string.IsNullOrWhiteSpace(clientPassword))
                {
                    context.ReasonCode = MqttConnectReasonCode.BadUserNameOrPassword;
                    return;
                }

                // 使用异步版本验证用户名密码
                bool isValid = await USERBLL.CheckAsync(clientUsername, clientPassword);
                if (isValid)
                {
                    context.ReasonCode = MqttConnectReasonCode.Success;
                }
                else
                {
                    context.ReasonCode = MqttConnectReasonCode.BadUserNameOrPassword;
                }
            }
            catch (Exception ex)
            {
                // 记录异常详细信息
                context.ReasonCode = MqttConnectReasonCode.ServerUnavailable;
            }
        }


        private void MQTT_Load(object sender, EventArgs e)
        {
            //注册连接认证方法
            mqttServer.ValidatingConnectionAsync += HandleValidatingConnectionAsync;
            //注册连接方法
            mqttServer.ClientConnectedAsync += OnClientConnected;
            //注册断连方法
            mqttServer.ClientDisconnectedAsync += OnClientDisconnected;
            //注册订阅处理方法
            mqttServer.ClientSubscribedTopicAsync += OnClientSubscribed;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        //服务器启动与停止
        private async void bt_Start_Click(object sender, EventArgs e)
        {
            if (mqttServer.IsStarted)
            {
                MessageBox.Show("请勿重复操作！");
                return;
            }
            try
            {
                await mqttServer.StartAsync();
                MessageBox.Show("服务器启动成功！");
                lb_Options.Text = "服务器已经【启动】，请勿重复操作";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"服务器启动失败: {ex.Message}");
            }
        }
        private async void bt_Stop_Click(object sender, EventArgs e)
        {

            if (mqttServer != null && mqttServer.IsStarted)
            {
                try
                {
                    await mqttServer.StopAsync();
                    MessageBox.Show("服务器停止成功！");
                    lb_Options.Text = "服务器已经【停止】";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"服务器停止失败: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("服务器未启动，请勿重复操作！");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExamDAL examDAL = new ExamDAL();
            ExamBLL examBLL = new ExamBLL(examDAL);
            examBLL.GenerateExamSchedule();
            MessageBox.Show("排考成功");
        }
    }
}
