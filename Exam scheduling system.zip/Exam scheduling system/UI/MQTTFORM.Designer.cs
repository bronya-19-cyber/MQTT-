﻿namespace UI
{
    partial class MQTTFORM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lt_Users = new ListBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            lt_Theme = new ListBox();
            panel1 = new Panel();
            lb_Options = new Label();
            bt_Stop = new Button();
            bt_Start = new Button();
            button1 = new Button();
            tableLayoutPanel1.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // lt_Users
            // 
            lt_Users.Dock = DockStyle.Fill;
            lt_Users.FormattingEnabled = true;
            lt_Users.Location = new Point(3, 24);
            lt_Users.Margin = new Padding(3, 4, 3, 4);
            lt_Users.Name = "lt_Users";
            lt_Users.Size = new Size(856, 185);
            lt_Users.TabIndex = 0;
            lt_Users.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(groupBox1, 0, 0);
            tableLayoutPanel1.Controls.Add(groupBox2, 0, 1);
            tableLayoutPanel1.Controls.Add(panel1, 0, 2);
            tableLayoutPanel1.Location = new Point(0, 5);
            tableLayoutPanel1.Margin = new Padding(3, 4, 3, 4);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 237F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 121F));
            tableLayoutPanel1.Size = new Size(868, 579);
            tableLayoutPanel1.TabIndex = 1;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lt_Users);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Location = new Point(3, 4);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(862, 213);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "在线账户";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lt_Theme);
            groupBox2.Dock = DockStyle.Fill;
            groupBox2.Location = new Point(3, 225);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(862, 229);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "已有主题";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // lt_Theme
            // 
            lt_Theme.Dock = DockStyle.Fill;
            lt_Theme.FormattingEnabled = true;
            lt_Theme.Location = new Point(3, 24);
            lt_Theme.Margin = new Padding(3, 4, 3, 4);
            lt_Theme.Name = "lt_Theme";
            lt_Theme.Size = new Size(856, 201);
            lt_Theme.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(button1);
            panel1.Controls.Add(lb_Options);
            panel1.Controls.Add(bt_Stop);
            panel1.Controls.Add(bt_Start);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(3, 462);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(862, 113);
            panel1.TabIndex = 4;
            // 
            // lb_Options
            // 
            lb_Options.AutoSize = true;
            lb_Options.Location = new Point(3, 0);
            lb_Options.Name = "lb_Options";
            lb_Options.Size = new Size(234, 20);
            lb_Options.TabIndex = 2;
            lb_Options.Text = "服务器已【停止】，请勿重复操作";
            // 
            // bt_Stop
            // 
            bt_Stop.Location = new Point(670, 64);
            bt_Stop.Margin = new Padding(3, 4, 3, 4);
            bt_Stop.Name = "bt_Stop";
            bt_Stop.Size = new Size(84, 31);
            bt_Stop.TabIndex = 1;
            bt_Stop.Text = "停止";
            bt_Stop.UseVisualStyleBackColor = true;
            bt_Stop.Click += bt_Stop_Click;
            // 
            // bt_Start
            // 
            bt_Start.Location = new Point(579, 64);
            bt_Start.Margin = new Padding(3, 4, 3, 4);
            bt_Start.Name = "bt_Start";
            bt_Start.Size = new Size(84, 31);
            bt_Start.TabIndex = 0;
            bt_Start.Text = "启动";
            bt_Start.UseVisualStyleBackColor = true;
            bt_Start.Click += bt_Start_Click;
            // 
            // button1
            // 
            button1.Location = new Point(468, 66);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 3;
            button1.Text = "排考";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // MQTTFORM
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 600);
            Controls.Add(tableLayoutPanel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "MQTTFORM";
            Text = "MQTT";
            Load += MQTT_Load;
            tableLayoutPanel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lt_Users;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lt_Theme;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt_Start;
        private System.Windows.Forms.Button bt_Stop;
        private System.Windows.Forms.Label lb_Options;
        private Button button1;
    }
}