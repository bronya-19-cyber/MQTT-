﻿using System.Data;
using Entity;
using MySql.Data.MySqlClient;
using TOOL;
using static NPOI.HSSF.Util.HSSFColor;

namespace DAL
{
    public class USERDAL
    {
        //密码查询方法
        public async Task<string> GetPasswordAsync(string userName)
        {
            string sqlStr = "select * from 登录信息表 where 学生学号=@username";
            var queryParams = new MySqlParameter[] {
                MySQLHelper.CreateParameter("@username", MySqlDbType.VarChar, userName)
            };

            DataTable dt = await MySQLHelper.ExecuteDataTableAsync(sqlStr,queryParams);
            if (dt.Rows.Count > 0)
            {
                object value = dt.Rows[0]["密码"];
                // 先判断是否为 DBNull.Value，不是的话再调用 ToString
                return value != DBNull.Value ? value!.ToString() : "Error";
            }
            else
            {
                return "Error";
            }
        }

        //查询学生考试数据方法
        public async Task<List<StudentExamData>> GetEXAMAsync(string Id)
        {
            string sql =
                "SELECT DISTINCT ci.课程名称,ei.考试时间,t1.教师姓名 AS 监考老师1,t2.教师姓名 AS 监考老师2,cl.教室编号,cl.位置 AS 考试地点 " +
                "FROM 课程信息管理 ci " +
                "JOIN 考试信息管理 ei ON ci.课程代码 = ei.考试课程 " +
                "JOIN 教室信息管理 cl ON ei.考试地点 = cl.教室编号 " +
                "JOIN 教师信息管理 t1 ON ei.监考老师1 = t1.教师工号 " +
                "JOIN 教师信息管理 t2 ON ei.监考老师2 = t2.教师工号 " +
                "WHERE ci.选课班级 LIKE CONCAT('%', (SELECT 班级 FROM 学生信息管理 WHERE 学生学号 = @Id), '%')";
            var queryParams = new MySqlParameter[] {
                MySQLHelper.CreateParameter("@Id", MySqlDbType.VarChar,Id)
            };
            try
            {
                var dt = await MySQLHelper.ExecuteDataTableAsync(sql,queryParams);
                List<StudentExamData> examdata = new List<StudentExamData>();
                foreach (DataRow row in dt.Rows)
                {
                    //学生考试数据列表中添加新的数据
                    examdata.Add(new StudentExamData
                    {
                        ExamName = row["课程名称"]?.ToString(),
                        ExamTime = row["考试时间"]?.ToString(),
                        ExamTeacher1 = row["监考老师1"]?.ToString(),
                        ExamTeacher2 = row["监考老师2"]?.ToString(),
                        ExamClassRoom = row["教室编号"]?.ToString(),
                        ExamLocation = row["考试地点"]?.ToString(),
                    });
                }
                return examdata;
            }
            catch (Exception ex)
            {
                return new List<StudentExamData>();
            }
        }

        //查询
    }
}
