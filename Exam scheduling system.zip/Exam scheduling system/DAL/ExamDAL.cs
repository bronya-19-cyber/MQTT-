﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using TOOL;
using static Entity.GETDATA;
using System.Data;
using NPOI.SS.Formula.Functions;

namespace DAL
{
    public class ExamDAL
    {
        // 获取所有课程
        public List<Course> GetAllCourses()
        {
            List<Course> courses = new List<Course>();
            string query = "SELECT 课程代码, 课程名称, 选课人数 FROM 课程信息管理";
            DataTable dt = MySQLHelper.ExecuteDataTable(query);

            foreach (DataRow row in dt.Rows)
            {
                Course course = new Course
                {
                    CourseId = (long)row["课程代码"],
                    CourseName = row["课程名称"].ToString(),
                    EnrollmentCount = (int)row["选课人数"]
                };
                courses.Add(course);
            }
            return courses;
        }

        // 获取所有教室
        public List<Classroom> GetAllClassrooms()
        {
            List<Classroom> classrooms = new List<Classroom>();
            string query = "SELECT 教室编号, 容量, 位置 FROM 教室信息管理";
            DataTable dt = MySQLHelper.ExecuteDataTable(query);

            foreach (DataRow row in dt.Rows)
            {
                Classroom classroom = new Classroom
                {
                    ClassroomId = (long)row["教室编号"],
                    Capacity = (int)row["容量"],
                    Location = row["位置"].ToString()
                };
                classrooms.Add(classroom);
            }

            return classrooms;
        }

        // 获取所有教师
        public List<Teacher> GetAllTeachers()
        {
            List<Teacher> teachers = new List<Teacher>();
            string query = "SELECT 教师工号, 教师姓名 FROM 教师信息管理";
            DataTable dt = MySQLHelper.ExecuteDataTable(query);

            foreach (DataRow row in dt.Rows)
            {
                Teacher teacher = new Teacher
                {
                    TeacherId = (long)row["教师工号"],
                    TeacherName = row["教师姓名"].ToString()
                };
                teachers.Add(teacher);
            }

            return teachers;
        }

        // 插入考试信息
        public void InsertExam(Exam exam)
        {
            string query = "INSERT INTO 考试信息管理 (考试课程, 考试时间, 监考老师1, 监考老师2, 考试地点) VALUES (@CourseId, @ExamTime, @Teacher1Id, @Teacher2Id, @ClassroomId)";
            MySqlParameter[] parameters =
            {
            MySQLHelper.CreateParameter("@CourseId", MySqlDbType.Int32, exam.CourseId),
            MySQLHelper.CreateParameter("@ExamTime", MySqlDbType.VarChar, exam.ExamTime),
            MySQLHelper.CreateParameter("@Teacher1Id", MySqlDbType.Int32, exam.Teacher1Id),
            MySQLHelper.CreateParameter("@Teacher2Id", MySqlDbType.Int32, exam.Teacher2Id),
            MySQLHelper.CreateParameter("@ClassroomId", MySqlDbType.Int32, exam.ClassroomId)
        };
            MySQLHelper.ExecuteNonQuery(query, parameters);
        }
    }
}
