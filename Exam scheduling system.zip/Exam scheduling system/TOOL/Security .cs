﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace TOOL
{
    public class Security
    {
        /// <summary>
        /// 进行DES加密（注：DES已不推荐用于高安全场景，建议升级AES）
        /// </summary>
        /// <param name="pToEncrypt">要加密的字符串</param>
        /// <param name="sKey">密钥（必须为8位）</param>
        /// <returns>Base64格式的加密字符串</returns>
        public string Encrypt(string pToEncrypt, string sKey)
        {
            // 替换废弃的DESCryptoServiceProvider为DES.Create()
            using (var des = DES.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(pToEncrypt);
                des.Key = Encoding.ASCII.GetBytes(sKey); // 8字节密钥
                des.IV = Encoding.ASCII.GetBytes(sKey);  // 8字节初始化向量（IV）

                using var ms = new MemoryStream();
                using (var cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(inputBytes, 0, inputBytes.Length);
                    cs.FlushFinalBlock();
                }
                return Convert.ToBase64String(ms.ToArray());
            }
        }

        /// <summary>
        /// 进行DES解密
        /// </summary>
        /// <param name="pToDecrypt">Base64加密字符串</param>
        /// <param name="sKey">密钥（必须为8位）</param>
        /// <returns>解密后的字符串</returns>
        public string Decrypt(string pToDecrypt, string sKey)
        {
            byte[] inputBytes = Convert.FromBase64String(pToDecrypt);
            using (var des = DES.Create())
            {
                des.Key = Encoding.ASCII.GetBytes(sKey);
                des.IV = Encoding.ASCII.GetBytes(sKey);

                using var ms = new MemoryStream();
                using (var cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(inputBytes, 0, inputBytes.Length);
                    cs.FlushFinalBlock();
                }
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        /// <summary>
        /// MD5哈希（注：MD5已不推荐用于安全场景，仅用于非敏感哈希）
        /// </summary>
        /// <param name="input">待哈希字符串</param>
        /// <returns>32位十六进制字符串</returns>
        public string Md5Hash(string input)
        {
            // 替换废弃的MD5CryptoServiceProvider为MD5.Create()
            using (var md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }
    }
}