﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Entity.GETDATA;
using static DAL.ExamDAL;
using DAL;

namespace BLL
{
    public class ExamBLL
    {
        private ExamDAL examDAL;

        public ExamBLL(ExamDAL examDAL)
        {
            this.examDAL = examDAL;
        }

        public void GenerateExamSchedule()
        {
            List<Course> courses = examDAL.GetAllCourses();
            List<Classroom> classrooms = examDAL.GetAllClassrooms();
            List<Teacher> teachers = examDAL.GetAllTeachers();

            // 按选课人数对课程排序（可选优化）
            courses = courses.OrderByDescending(c => c.EnrollmentCount).ToList();

            // 考试时间安排：每天早中晚三场
            string[] dailyExamTimes = { "早上", "中午", "晚上" };
            int currentDay = 1;
            int currentDailyTimeIndex = 0;
            int currentTeacherIndex = 0;
            int currentClassroomIndex = 0;

            foreach (Course course in courses)
            {
                // 选择合适的教室（优先使用容量接近的教室）
                Classroom selectedClassroom = SelectSuitableClassroom(classrooms, ref currentClassroomIndex, course.EnrollmentCount);
                if (selectedClassroom == null)
                {
                    throw new Exception("没有足够容量的教室来安排考试");
                }

                // 选择两位监考教师
                Teacher teacher1 = teachers[currentTeacherIndex];
                currentTeacherIndex = (currentTeacherIndex + 1) % teachers.Count;
                Teacher teacher2 = teachers[currentTeacherIndex];
                currentTeacherIndex = (currentTeacherIndex + 1) % teachers.Count;

                // 生成考试时间（格式：第X天-早上/中午/晚上）
                string examTime = $"第{currentDay}天-{dailyExamTimes[currentDailyTimeIndex]}";

                // 创建考试记录
                Exam exam = new Exam
                {
                    CourseId = course.CourseId,
                    ExamTime = examTime,
                    Teacher1Id = teacher1.TeacherId,
                    Teacher2Id = teacher2.TeacherId,
                    ClassroomId = selectedClassroom.ClassroomId
                };

                examDAL.InsertExam(exam);

                // 更新时间索引：早→中→晚→下一天
                currentDailyTimeIndex = (currentDailyTimeIndex + 1) % dailyExamTimes.Length;
                if (currentDailyTimeIndex == 0) // 当天三场排完，进入下一天
                {
                    currentDay++;
                }
            }
        }

        private Classroom SelectSuitableClassroom(List<Classroom> classrooms, ref int startIndex, int requiredCapacity)
        {
            int initialIndex = startIndex;
            do
            {
                if (classrooms[startIndex].Capacity >= requiredCapacity)
                {
                    Classroom selected = classrooms[startIndex];
                    startIndex = (startIndex + 1) % classrooms.Count; // 循环使用教室
                    return selected;
                }
                startIndex = (startIndex + 1) % classrooms.Count;
            } while (startIndex != initialIndex); // 避免无限循环

            return null; // 没有找到合适的教室
        }
    }
}
