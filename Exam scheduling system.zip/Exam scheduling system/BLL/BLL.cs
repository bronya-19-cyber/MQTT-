﻿using Entity;
using TOOL;

namespace BLL
{
    public class USERBLL
    {
        public static async Task<bool> CheckAsync(string userName, string userPassword)
        {
            Security sec = new Security();
            DAL.USERDAL ud = new DAL.USERDAL();


            string password = await ud.GetPasswordAsync(userName);

            // 直接比较结果，不需要使用await true
            return password == sec.Md5Hash(userPassword);
        }

        //获取学生的考试信息
        public static async Task<List<StudentExamData>>GetStudentByIdAsync(string Id)
        {
            DAL.USERDAL ud = new DAL.USERDAL();
            List<StudentExamData> ExamData = new List<StudentExamData>();
            ExamData = await ud.GetEXAMAsync(Id);
            return ExamData;
        }
    }
}
