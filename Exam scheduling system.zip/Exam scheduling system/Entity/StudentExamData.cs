﻿namespace Entity
{
    public class StudentExamData
    {
        //考试科目
        public required string ExamName { get; set; }
        //考试时间
        public required string ExamTime { get; set; }
        //监考教师
        public required string ExamTeacher1 { get; set; }
        public required string ExamTeacher2 { get; set; }
        //考试地点
        public required string ExamClassRoom { get; set; }
        public required string ExamLocation { get; set; }

    }
}
