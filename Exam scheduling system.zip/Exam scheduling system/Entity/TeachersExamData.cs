﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    internal class TeachersExamData
    {
        //考试科目
        public required string ExamName { get; set; }
        //考试时间
        public required string ExamTime { get; set; }
        //考试地点
        public required string ExamLocation { get; set; }
    }
}
