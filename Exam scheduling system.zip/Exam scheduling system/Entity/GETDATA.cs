﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class GETDATA
    {
        public class Course
        {
            public long CourseId { get; set; }
            public string CourseName { get; set; }
            public int EnrollmentCount { get; set; }
        }

        // 教室模型
        public class Classroom
        {
            public long ClassroomId { get; set; }
            public int Capacity { get; set; }
            public string Location { get; set; }
        }

        // 教师模型
        public class Teacher
        {
            public long TeacherId { get; set; }
            public string TeacherName { get; set; }
        }

        // 考试模型
        public class Exam
        {
            public long ExamId { get; set; }
            public long CourseId { get; set; }
            public string ExamTime { get; set; }
            public long Teacher1Id { get; set; }
            public long Teacher2Id { get; set; }
            public long ClassroomId { get; set; }
        }
    }
}
