﻿namespace UI
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            tb_Password = new TextBox();
            tb_UserName = new TextBox();
            label1 = new Label();
            bt_login = new Button();
            Password = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(tb_Password);
            panel1.Controls.Add(tb_UserName);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(bt_login);
            panel1.Controls.Add(Password);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(792, 447);
            panel1.TabIndex = 1;
            // 
            // tb_Password
            // 
            tb_Password.Location = new Point(334, 215);
            tb_Password.Name = "tb_Password";
            tb_Password.PasswordChar = '*';
            tb_Password.Size = new Size(252, 27);
            tb_Password.TabIndex = 9;
            tb_Password.TextChanged += tb_Password_TextChanged;
            // 
            // tb_UserName
            // 
            tb_UserName.Location = new Point(334, 135);
            tb_UserName.Name = "tb_UserName";
            tb_UserName.Size = new Size(252, 27);
            tb_UserName.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(238, 142);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 5;
            label1.Text = "工号/学号：";
            // 
            // bt_login
            // 
            bt_login.Location = new Point(334, 348);
            bt_login.Name = "bt_login";
            bt_login.Size = new Size(94, 29);
            bt_login.TabIndex = 7;
            bt_login.Text = "登录";
            bt_login.UseVisualStyleBackColor = true;
            bt_login.Click += bt_login_Click;
            // 
            // Password
            // 
            Password.AutoSize = true;
            Password.Location = new Point(238, 218);
            Password.Name = "Password";
            Password.Size = new Size(54, 20);
            Password.TabIndex = 6;
            Password.Text = "密码：";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Location = new Point(3, -1);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(798, 453);
            tableLayoutPanel1.TabIndex = 2;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "Login";
            Text = "Login";
            Load += Login_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox tb_Password;
        private TextBox tb_UserName;
        private Label label1;
        private Button bt_login;
        private Label Password;
        private TableLayoutPanel tableLayoutPanel1;
    }
}