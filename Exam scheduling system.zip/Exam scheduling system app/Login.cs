﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Extensions.DependencyInjection;
using MQTTnet;
using MQTTnet.Adapter;
using MQTTnet.Client;
using MQTTnet.Exceptions;
using MQTTnet.Extensions.ManagedClient;



namespace UI
{
    public partial class Login : Form
    {
        public Login(IMqttClient mqttClient, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _mqttClient = mqttClient;
            _serviceProvider = serviceProvider;
        }
        private readonly IMqttClient _mqttClient;
        private readonly IServiceProvider _serviceProvider;
        private void tb_Password_TextChanged(object sender, EventArgs e)
        {

        }

        private async void bt_login_Click(object sender, EventArgs e)
        {
            try
            {
                //创建连接参数
                var options = new MqttClientOptionsBuilder()
                    .WithTcpServer("127.0.0.1",1883)
                    .WithClientId(tb_UserName.Text)
                    .WithCredentials(tb_UserName.Text, tb_Password.Text)
                    .WithCleanSession()
                    .Build();

                // 添加超时控制
                using (var timeoutToken = new CancellationTokenSource(TimeSpan.FromSeconds(10)))
                {
                    await _mqttClient.ConnectAsync(options, timeoutToken.Token);
                }

                // 连接成功后的处理
                MessageBox.Show("MQTT客户端连接成功");
                
                //将MQTT客户端传递给新窗体
                var resultForm = _serviceProvider.GetRequiredService<Result>();
                resultForm.Show();
                this.Hide();
            }
            catch (MqttConnectingFailedException ex)
            {
                MessageBox.Show($"MQTT连接失败: {ex.ResultCode}");
            }
            catch (MqttCommunicationException ex)
            {
                MessageBox.Show($"通信错误: {ex.Message}");
            }
            catch (OperationCanceledException)
            {
                MessageBox.Show("连接超时");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"未知错误: {ex.Message}");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
