﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Microsoft.Extensions.DependencyInjection;
using MQTTnet;
using MQTTnet.Client;
using static System.Windows.Forms.Design.AxImporter;

namespace UI
{
    public partial class Result : Form
    {
        private Func<MqttApplicationMessageReceivedEventArgs, Task> _messageHandler;
        public Result(IMqttClient mqttClient,IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _mqttClient = mqttClient;
            _serviceProvider = serviceProvider;
            // 注册消息接收事件处理程序
            // 保存委托，用于后续取消订阅  
            _messageHandler = HandleMessageReceived;
            _mqttClient.ApplicationMessageReceivedAsync += HandleMessageReceived;
            // 初始化DataGridView
            InitializeDataGridView();
        }
        private readonly IMqttClient _mqttClient;
        private readonly IServiceProvider _serviceProvider;

        private void InitializeDataGridView()
        {
            DGV.Columns.Clear();
            // 设置DataGridView列
            DGV.Columns.Add("ExamName","考试科目");
            DGV.Columns.Add("ExamTime", "考试时间");
            DGV.Columns.Add("ExamTeacher1", "监考教师1");
            DGV.Columns.Add("ExamTeacher2", "监考教师2");
            DGV.Columns.Add("ExamClassRoom", "教室编号");
            DGV.Columns.Add("ExamLocation", "考场位置");

            // 设置其他属性
            DGV.AutoGenerateColumns = false;
            DGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void DGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private async void Result_Load(object sender, EventArgs e)
        {
            lb_UserName.Text = $"用户：【{_mqttClient.Options.ClientId}】已登录";
            var factory = new MqttFactory();
            var subscribeOptions = factory.CreateSubscribeOptionsBuilder()
                .WithTopicFilter(f => f.WithTopic($"student/{_mqttClient.Options.ClientId}"))
                .Build();
            await _mqttClient.SubscribeAsync(subscribeOptions);
        }

        private async  void bt_exit_Click(object sender, EventArgs e)
        {
            _mqttClient.ApplicationMessageReceivedAsync -= _messageHandler;
            await _mqttClient.UnsubscribeAsync($"student/{_mqttClient.Options.ClientId}");
            await _mqttClient.DisconnectAsync();
            // 断开成功后的处理
            MessageBox.Show("退出成功！");

            // 将MQTT客户端传回给login
            var resultForm = _serviceProvider.GetRequiredService<Login>();
            resultForm.Show();
            this.Close();    
        }

        //接收消息处理逻辑
        private Task HandleMessageReceived(MqttApplicationMessageReceivedEventArgs e)
        {
            try
            {
                // 确保在UI线程上更新DataGridView
                if (DGV.InvokeRequired)
                {
                    DGV.Invoke(new Action(() => ProcessMessage(e)));
                    return Task.CompletedTask;
                }

                ProcessMessage(e);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"处理消息失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return Task.CompletedTask;
        }

        private void ProcessMessage(MqttApplicationMessageReceivedEventArgs e)
        {
            // 转换消息内容为字符串
            var payload = Encoding.UTF8.GetString(e.ApplicationMessage.Payload);
            try
            {
                // 解析JSON数据
                var examdata = JsonSerializer.Deserialize<List<StudentExamData>>(payload);
                if (examdata != null)
                {
                    foreach (var student in examdata)
                    {
                        DGV.Rows.Add(student.ExamName, student.ExamTime, student.ExamTeacher1, student.ExamTeacher2,student.ExamClassRoom,student.ExamLocation);
                        lb_Count.Text = $"已接收数据，共 {examdata.Count} 条";
                    }
                }
            }
            catch (Exception ex)
            {
                lb_Count.Text = $"解析消息失败: {ex.Message}";
                MessageBox.Show($"消息格式错误: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
