﻿namespace UI
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DGV = new DataGridView();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1 = new Panel();
            bt_exit = new Button();
            lb_Count = new Label();
            lb_UserName = new Label();
            ((System.ComponentModel.ISupportInitialize)DGV).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // DGV
            // 
            DGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV.Dock = DockStyle.Fill;
            DGV.Location = new Point(3, 122);
            DGV.Name = "DGV";
            DGV.RowHeadersWidth = 51;
            DGV.Size = new Size(796, 326);
            DGV.TabIndex = 0;
            DGV.CellContentClick += DGV_CellContentClick;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Controls.Add(DGV, 0, 1);
            tableLayoutPanel1.Location = new Point(-3, -1);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 26.3858089F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 73.61419F));
            tableLayoutPanel1.Size = new Size(802, 451);
            tableLayoutPanel1.TabIndex = 1;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // panel1
            // 
            panel1.Controls.Add(bt_exit);
            panel1.Controls.Add(lb_Count);
            panel1.Controls.Add(lb_UserName);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(796, 113);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // bt_exit
            // 
            bt_exit.Location = new Point(694, 7);
            bt_exit.Name = "bt_exit";
            bt_exit.Size = new Size(94, 29);
            bt_exit.TabIndex = 3;
            bt_exit.Text = "退出登录";
            bt_exit.UseVisualStyleBackColor = true;
            bt_exit.Click += bt_exit_Click;
            // 
            // lb_Count
            // 
            lb_Count.AutoSize = true;
            lb_Count.Location = new Point(13, 80);
            lb_Count.Name = "lb_Count";
            lb_Count.Size = new Size(99, 20);
            lb_Count.TabIndex = 2;
            lb_Count.Text = "共【】场考试";
            lb_Count.Click += label1_Click_1;
            // 
            // lb_UserName
            // 
            lb_UserName.AutoSize = true;
            lb_UserName.Location = new Point(12, 7);
            lb_UserName.Name = "lb_UserName";
            lb_UserName.Size = new Size(129, 20);
            lb_UserName.TabIndex = 1;
            lb_UserName.Text = "用户：【】已登录";
            lb_UserName.Click += label1_Click;
            // 
            // Result
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            ControlBox = false;
            Controls.Add(tableLayoutPanel1);
            Name = "Result";
            Text = "Result";
            Load += Result_Load;
            ((System.ComponentModel.ISupportInitialize)DGV).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DGV;
        private TableLayoutPanel tableLayoutPanel1;
        private Label lb_UserName;
        private Panel panel1;
        private Label lb_Count;
        private Button bt_exit;
    }
}